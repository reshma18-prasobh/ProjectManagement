﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ProjectManagement.Web.Helper;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement.Web.Controllers
{
    public class ProjectsController : Controller
    {
        ProjectAPI _projectAPI = new ProjectAPI();

        public async Task<IActionResult> Index()
        {
            List<ProjectDTO> dto = new List<ProjectDTO>();

            HttpClient client = _projectAPI.InitializeClient();

            HttpResponseMessage res = await client.GetAsync("api/project");

            //Checking the response is successful or not which is sent using HttpClient    
            if (res.IsSuccessStatusCode)
            {
                //Storing the response details recieved from web api     
                var result = res.Content.ReadAsStringAsync().Result;

                //Deserializing the response recieved from web api and storing into the Employee list    
                dto = JsonConvert.DeserializeObject<List<ProjectDTO>>(result);

            }
            //returning the employee list to view    
            return View(dto);
        }

        // GET: Projects/Create  
        public IActionResult Create()
        {
            return View();
        }

        // POST: Projects/Create  
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("ProjectId,ProjectName,Description,StartDate,EndDate,ProjectStatus")] ProjectDTO project)
        {
            if (ModelState.IsValid)
            {
                HttpClient client = _projectAPI.InitializeClient();

                var content = new StringContent(JsonConvert.SerializeObject(project), Encoding.UTF8, "application/json");
                HttpResponseMessage res = client.PostAsync("api/project", content).Result;
                if (res.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return View(project);
        }

        // GET: Projects/Edit/1  
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            List<ProjectDTO> dto = new List<ProjectDTO>();
            HttpClient client = _projectAPI.InitializeClient();
            HttpResponseMessage res = await client.GetAsync("api/project");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                dto = JsonConvert.DeserializeObject<List<ProjectDTO>>(result);
            }

            var project = dto.SingleOrDefault(m => m.ProjectId == id);
            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }

        // POST: Projects/Edit/1  
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("ProjectId,ProjectName,Description,StartDate,EndDate,ProjectStatus")] ProjectDTO project)
        {
            if (id != project.ProjectId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                HttpClient client = _projectAPI.InitializeClient();

                var content = new StringContent(JsonConvert.SerializeObject(project), Encoding.UTF8, "application/json");
                HttpResponseMessage res = client.PutAsync("api/project", content).Result;
                if (res.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return View(project);
        }

        // GET: Projects/Delete/1  
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            List<ProjectDTO> dto = new List<ProjectDTO>();
            HttpClient client = _projectAPI.InitializeClient();
            HttpResponseMessage res = await client.GetAsync("api/project");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                dto = JsonConvert.DeserializeObject<List<ProjectDTO>>(result);
            }

            var project = dto.SingleOrDefault(m => m.ProjectId == id);
            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }

        // POST: Projects/Delete/5  
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(long id)
        {
            HttpClient client = _projectAPI.InitializeClient();
            HttpResponseMessage res = client.DeleteAsync($"api/project/{id}").Result;
            if (res.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return NotFound();
        }

    }
}